// Form1.cpp — IMGUI_GOD_SSSTIER editöründen ÜRETİLDİ
// Değişiklikleri USER bölgelerine yazın; editör üretim bloklarını yeniler.
#include "Form1.h"

//== IMGOD:INIT-BEGIN (editör üretimi — elle değiştirmeyin)
void Form1::Render() {
    ImGui::SetNextWindowSize(ImVec2(700, 580), ImGuiCond_FirstUseEver);
    if (!ImGui::Begin(u8"Form1", nullptr, 0)) { ImGui::End();
        return; }
    ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0.102f, 0.1255f, 0.1882f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0.2275f, 0.2902f, 0.4f, 1.0f));
    ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, 6.0f);
    ImGui::SetCursorPos(ImVec2(24, 24));
    panel1.Begin();
    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.0f, 1.0f, 1.0f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.8235f, 0.3294f, 0.06275f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.9333f, 0.4784f, 0.1882f, 1.0f));
    ImGui::SetCursorPos(ImVec2(140, 85));
    if (ImGui::Button(u8"Panel İçi Buton##button1", ImVec2(120, 28))) button1_Click();
    ImGui::PopStyleColor(3);
    panel1.End();
    ImGui::PopStyleVar(1);
    ImGui::PopStyleColor(2);
    ImGui::SetCursorPos(ImVec2(24, 220));
    if (textBox1.Draw()) textBox1_TextChanged();
    ImGui::SetCursorPos(ImVec2(24, 260));
    ImGui::SetNextItemWidth(240.0f);
    ImGui::LabelText(u8"Alan##labelText1", u8"değer");
    ImGui::SetCursorPos(ImVec2(24, 295));
    ImGui::PushTextWrapPos(ImGui::GetCursorPos().x + 240.0f);
    ImGui::Text(u8"Bu uzun metin tasarım genişliğinde satırlara kırılır");
    ImGui::PopTextWrapPos();
    ImGui::SetCursorPos(ImVec2(320, 24));
    checkbox1.Checked0 = false;
    if (checkbox1.Draw()) checkbox1_Checked();
    ImGui::SetCursorPos(ImVec2(320, 70));
    if (radioButton1.Draw()) radioButton1_Click();
    ImGui::PushStyleColor(ImGuiCol_Separator, ImVec4(0.3529f, 0.3529f, 0.3843f, 1.0f));
    ImGui::SetCursorPos(ImVec2(320, 115));
    separator1.Draw();
    ImGui::PopStyleColor(1);
    ImGui::SetCursorPos(ImVec2(320, 140));
    separatorText1.Draw();
    ImGui::SetCursorPos(ImVec2(320, 175));
    bulletText1.Draw();
    ImGui::SetCursorPos(ImVec2(500, 24));
    if (sliderFloat1.Draw()) sliderFloat1_ValueChanged();
    ImGui::SetCursorPos(ImVec2(500, 70));
    if (combo1.Draw()) combo1_SelectionChanged();
    ImGui::SetCursorPos(ImVec2(500, 110));
    if (listBox1.Draw()) listBox1_SelectionChanged();
    ImGui::SetCursorPos(ImVec2(500, 220));
    progressBar1.Draw();
    ImGui::SetCursorPos(ImVec2(24, 340));
    if (tabBar1.Begin()) {
    if (ImGui::BeginTabItem(u8"Genel")) {
    ImGui::SetCursorPos(ImVec2(210, 110));
    if (ImGui::Button(u8"Sekme Butonu##button2", ImVec2(120, 28))) button2_Click();
        ImGui::EndTabItem();
    }
    if (ImGui::BeginTabItem(u8"Ayarlar")) {
        ImGui::EndTabItem();
    }
    if (ImGui::BeginTabItem(u8"Hakkında")) {
        ImGui::EndTabItem();
    }
    }
    tabBar1.End();   // child dengesi — her zaman
    ImGui::SetCursorPos(ImVec2(500, 260));
    groupBox1.Begin();
    ImGui::SetCursorPos(ImVec2(88, 70));
    if (textBox2.Draw()) textBox2_TextChanged();
    groupBox1.End();
    ImGui::End();
}
//== IMGOD:INIT-END

//== IMGOD:HANDLERS-BEGIN
void Form1::panel1_Hovered() {
    // TODO: panel1 → Hovered (Fare üstüne gelince) — kodunuzu yazın
}

void Form1::button1_Click() {
    // TODO: button1 → Click (Tıklandığında) — kodunuzu yazın
}

void Form1::button1_Hovered() {
    // TODO: button1 → Hovered (Fare üstüne gelince) — kodunuzu yazın
}

void Form1::button1_Held() {
    // TODO: button1 → Held (Basılı tutulunca) — kodunuzu yazın
}

void Form1::textBox1_TextChanged() {
    // TODO: textBox1 → TextChanged (Yazı değişince) — kodunuzu yazın
}

void Form1::textBox1_EnterPressed() {
    // TODO: textBox1 → EnterPressed (Enter'a basılınca) — kodunuzu yazın
}

void Form1::checkbox1_Checked() {
    // TODO: checkbox1 → Checked (İşaret değişince) — kodunuzu yazın
}

void Form1::radioButton1_Click() {
    // TODO: radioButton1 → Click (Seçilince) — kodunuzu yazın
}

void Form1::sliderFloat1_ValueChanged() {
    // TODO: sliderFloat1 → ValueChanged (Değer kayarken) — kodunuzu yazın
}

void Form1::sliderFloat1_Deactivated() {
    // TODO: sliderFloat1 → Deactivated (Kaydırma bitince) — kodunuzu yazın
}

void Form1::combo1_SelectionChanged() {
    // TODO: combo1 → SelectionChanged (Seçim değişince) — kodunuzu yazın
}

void Form1::listBox1_SelectionChanged() {
    // TODO: listBox1 → SelectionChanged (Seçim değişince) — kodunuzu yazın
}

void Form1::progressBar1_Hovered() {
    // TODO: progressBar1 → Hovered (Fare üstüne gelince) — kodunuzu yazın
}

void Form1::tabBar1_TabChanged() {
    // TODO: tabBar1 → TabChanged (Aktif sekme değişince) — kodunuzu yazın
}

void Form1::button2_Click() {
    // TODO: button2 → Click (Tıklandığında) — kodunuzu yazın
}

void Form1::button2_Hovered() {
    // TODO: button2 → Hovered (Fare üstüne gelince) — kodunuzu yazın
}

void Form1::button2_Held() {
    // TODO: button2 → Held (Basılı tutulunca) — kodunuzu yazın
}

void Form1::textBox2_TextChanged() {
    // TODO: textBox2 → TextChanged (Yazı değişince) — kodunuzu yazın
}

void Form1::textBox2_EnterPressed() {
    // TODO: textBox2 → EnterPressed (Enter'a basılınca) — kodunuzu yazın
}

//== IMGOD:HANDLERS-END

Form1::Form1() {
    panel1.Text = u8"Panel##panel1";
    panel1.Size = ImVec2(280, 170);
    panel1.Border = true;
    panel1.Rounding = 6.0f;
    textBox1.Text = u8"Yazı##textBox1";
    textBox1.Value = u8"Metin girin...";
    textBox1.Hint = u8"";
    textBox1.Password = false;
    textBox1.ReadOnly = false;
    textBox1.Width = 240;
    checkbox1.Text = u8"Büyük onay kutusu##checkbox1";
    checkbox1.Width = 170;
    checkbox1.Height = 34;
    radioButton1.Text = u8"Seçenek A##radioButton1";
    radioButton1.Active = false;
    radioButton1.Width = 150;
    radioButton1.Height = 30;
    separator1.Size = ImVec2(240, 8);
    separatorText1.Text = u8"Bölüm##separatorText1";
    separatorText1.Width = 240;
    bulletText1.Text = u8"Genişliğe sığan madde";
    bulletText1.Width = 200;
    sliderFloat1.Text = u8"Değer##sliderFloat1";
    sliderFloat1.Value = 40.0f;
    sliderFloat1.Min = 0.0f;
    sliderFloat1.Max = 100.0f;
    sliderFloat1.Format = u8"%.1f";
    sliderFloat1.Width = 170;
    combo1.Text = u8"Seçim##combo1";
    combo1.Items = { u8"Seçenek 1", u8"Seçenek 2", u8"Seçenek 3" };
    combo1.Selected = 0;
    combo1.Width = 170;
    listBox1.Text = u8"Liste##listBox1";
    listBox1.Items = { u8"Öğe 1", u8"Öğe 2", u8"Öğe 3" };
    listBox1.Selected = 0;
    listBox1.HeightItems = 5;
    listBox1.Size = ImVec2(170, 96);
    progressBar1.Value = 0.7f;
    progressBar1.Overlay = u8"";
    progressBar1.Size = ImVec2(200, 18);
    tabBar1.Text = u8"Sekmeler##tabBar1";
    tabBar1.Size = ImVec2(420, 220);
    groupBox1.Text = u8"Grup";
    groupBox1.Id = u8"groupBox1";
    groupBox1.Size = ImVec2(176, 140);
    textBox2.Text = u8"Yazı##textBox2";
    textBox2.Value = u8"";
    textBox2.Hint = u8"";
    textBox2.Password = false;
    textBox2.ReadOnly = false;
    textBox2.Width = 140;
}
Form1::~Form1() {}
void Form1::OnLoad() {
    // TODO: form yüklendiğinde çalışacak kod
}
