// Form1.cpp — IMGUI_GOD_SSSTIER editöründen ÜRETİLDİ
// Değişiklikleri USER bölgelerine yazın; editör üretim bloklarını yeniler.
#include "Form1.h"

//== IMGOD:INIT-BEGIN (editör üretimi — elle değiştirmeyin)
void Form1::Render() {
    ImGui::SetNextWindowSize(ImVec2(640, 560), ImGuiCond_FirstUseEver);
    if (!ImGui::Begin(u8"Form1", nullptr, 0)) { ImGui::End();
        return; }
    ImGui::SetCursorPos(ImVec2(24, 40));
    groupBox1.Begin();
    ImGui::SetCursorPos(ImVec2(36, 30));
    if (textBox1.Draw()) textBox1_TextChanged();
    ImGui::SetCursorPos(ImVec2(36, 80));
    if (ImGui::Button(u8"Gönder##button1", ImVec2(120, 28))) button1_Click();
    ImGui::SetCursorPos(ImVec2(36, 150));
    checkbox1.Checked0 = false;
    if (checkbox1.Draw()) checkbox1_Checked();
    groupBox1.End();
    ImGui::SetCursorPos(ImVec2(360, 40));
    panel1.Begin();
    ImGui::SetCursorPos(ImVec2(40, 60));
    if (sliderFloat1.Draw()) sliderFloat1_ValueChanged();
    ImGui::SetCursorPos(ImVec2(40, 150));
    if (combo1.Draw()) combo1_SelectionChanged();
    panel1.End();
    ImGui::SetCursorPos(ImVec2(24, 280));
    if (textBoxMultiline1.Draw()) textBoxMultiline1_TextChanged();
    ImGui::SetCursorPos(ImVec2(24, 400));
    progressBar1.Draw();
    ImGui::SetCursorPos(ImVec2(360, 300));
    separator1.Draw();
    ImGui::SetCursorPos(ImVec2(380, 380));
    if (ImGui::Button(u8"Temizle##button2", ImVec2(120, 28))) button2_Click();
    ImGui::End();
}
//== IMGOD:INIT-END

//== IMGOD:HANDLERS-BEGIN
void Form1::textBox1_TextChanged() {
    // TODO: textBox1 → TextChanged (Yazı değişince) — kodunuzu yazın
}

void Form1::textBox1_EnterPressed() {
    // TODO: textBox1 → EnterPressed (Enter'a basılınca) — kodunuzu yazın
}

void Form1::button1_Click() {
    // TODO: button1 → Click (Tıklandığında) — kodunuzu yazın
}

void Form1::button1_Hovered() {
    // TODO: button1 → Hovered (Fare üstüne gelince) — kodunuzu yazın
}

void Form1::button1_Held() {
    // TODO: button1 → Held (Basılı tutulunca) — kodunuzu yazın
}

void Form1::checkbox1_Checked() {
    // TODO: checkbox1 → Checked (İşaret değişince) — kodunuzu yazın
}

void Form1::panel1_Hovered() {
    // TODO: panel1 → Hovered (Fare üstüne gelince) — kodunuzu yazın
}

void Form1::sliderFloat1_ValueChanged() {
    // TODO: sliderFloat1 → ValueChanged (Değer kayarken) — kodunuzu yazın
}

void Form1::sliderFloat1_Deactivated() {
    // TODO: sliderFloat1 → Deactivated (Kaydırma bitince) — kodunuzu yazın
}

void Form1::combo1_SelectionChanged() {
    // TODO: combo1 → SelectionChanged (Seçim değişince) — kodunuzu yazın
}

void Form1::textBoxMultiline1_TextChanged() {
    // TODO: textBoxMultiline1 → TextChanged (Yazı değişince) — kodunuzu yazın
}

void Form1::progressBar1_Hovered() {
    // TODO: progressBar1 → Hovered (Fare üstüne gelince) — kodunuzu yazın
}

void Form1::button2_Click() {
    // TODO: button2 → Click (Tıklandığında) — kodunuzu yazın
}

void Form1::button2_Hovered() {
    // TODO: button2 → Hovered (Fare üstüne gelince) — kodunuzu yazın
}

void Form1::button2_Held() {
    // TODO: button2 → Held (Basılı tutulunca) — kodunuzu yazın
}

//== IMGOD:HANDLERS-END

Form1::Form1() {
    groupBox1.Text = u8"Giriş Alanı";
    groupBox1.Id = u8"groupBox1";
    groupBox1.Size = ImVec2(300, 200);
    textBox1.Text = u8"Yazı##textBox1";
    textBox1.Value = u8"Merhaba ImGui";
    textBox1.Hint = u8"";
    textBox1.Password = false;
    textBox1.ReadOnly = false;
    textBox1.Width = 200;
    textBox1.Height = 44;
    checkbox1.Text = u8"Beni hatırla##checkbox1";
    checkbox1.Width = 0;
    checkbox1.Height = 19;
    panel1.Text = u8"Panel##panel1";
    panel1.Size = ImVec2(250, 220);
    panel1.Border = true;
    panel1.Rounding = -1.0f;
    sliderFloat1.Text = u8"Hız##sliderFloat1";
    sliderFloat1.Value = 0.0f;
    sliderFloat1.Min = 0.0f;
    sliderFloat1.Max = 100.0f;
    sliderFloat1.Format = u8"%.1f";
    sliderFloat1.Width = 150;
    sliderFloat1.Height = 38;
    combo1.Text = u8"Seçim##combo1";
    combo1.Items = { u8"Seçenek 1", u8"Seçenek 2", u8"Seçenek 3" };
    combo1.Selected = 0;
    combo1.Width = 150;
    combo1.Height = 34;
    textBoxMultiline1.Text = u8"Not##textBoxMultiline1";
    textBoxMultiline1.Value = u8"";
    textBoxMultiline1.ReadOnly = false;
    textBoxMultiline1.Size = ImVec2(280, 90);
    progressBar1.Value = 0.5f;
    progressBar1.Overlay = u8"";
    progressBar1.Size = ImVec2(280, 22);
    separator1.Size = ImVec2(250, 4);
}
Form1::~Form1() {}
void Form1::OnLoad() {
    // TODO: form yüklendiğinde çalışacak kod
}
