// Form1.h — IMGUI_GOD_SSSTIER editöründen ÜRETİLDİ
#pragma once
#include "Global.h"

struct Form1 : IGOD::FormBase {
    IGOD::InputText textBox1;   // tasarım: Yazı
    // button1 : Button — tasarım: Gönder
    IGOD::Checkbox checkbox1;   // tasarım: Beni hatırla
    IGOD::GroupBox groupBox1;
    IGOD::SliderFloat sliderFloat1;   // tasarım: Hız
    IGOD::Combo combo1;
    IGOD::Panel panel1;
    IGOD::InputTextMultiline textBoxMultiline1;   // tasarım: Not
    IGOD::ProgressBar progressBar1;
    IGOD::Separator separator1;
    // button2 : Button — tasarım: Temizle
    void textBox1_TextChanged();   // textBox1: Yazı değişince
    void textBox1_EnterPressed();   // textBox1: Enter'a basılınca
    void button1_Click();   // button1: Tıklandığında
    void button1_Hovered();   // button1: Fare üstüne gelince
    void button1_Held();   // button1: Basılı tutulunca
    void checkbox1_Checked();   // checkbox1: İşaret değişince
    void panel1_Hovered();   // panel1: Fare üstüne gelince
    void sliderFloat1_ValueChanged();   // sliderFloat1: Değer kayarken
    void sliderFloat1_Deactivated();   // sliderFloat1: Kaydırma bitince
    void combo1_SelectionChanged();   // combo1: Seçim değişince
    void textBoxMultiline1_TextChanged();   // textBoxMultiline1: Yazı değişince
    void progressBar1_Hovered();   // progressBar1: Fare üstüne gelince
    void button2_Click();   // button2: Tıklandığında
    void button2_Hovered();   // button2: Fare üstüne gelince
    void button2_Held();   // button2: Basılı tutulunca
    void OnLoad() override;
    Form1();
    ~Form1() override;   // vtable bu TU'da bağlanır
    void Render() override;
};
