// Form1.h — IMGUI_GOD_SSSTIER editöründen ÜRETİLDİ
#pragma once
#include "Global.h"

struct Form1 : IGOD::FormBase {
    // button1 : Button — tasarım: Panel İçi Buton
    IGOD::Panel panel1;
    IGOD::InputText textBox1;   // tasarım: Yazı
    IGOD::Checkbox checkbox1;   // tasarım: Büyük onay kutusu
    IGOD::RadioButton radioButton1;
    IGOD::Separator separator1;
    IGOD::SeparatorText separatorText1;
    IGOD::BulletText bulletText1;
    IGOD::SliderFloat sliderFloat1;   // tasarım: Değer
    IGOD::Combo combo1;
    IGOD::ListBox listBox1;
    IGOD::ProgressBar progressBar1;
    // button2 : Button — tasarım: Sekme Butonu
    IGOD::TabBar tabBar1;
    IGOD::InputText textBox2;   // tasarım: Yazı
    IGOD::GroupBox groupBox1;
    void panel1_Hovered();   // panel1: Fare üstüne gelince
    void button1_Click();   // button1: Tıklandığında
    void button1_Hovered();   // button1: Fare üstüne gelince
    void button1_Held();   // button1: Basılı tutulunca
    void textBox1_TextChanged();   // textBox1: Yazı değişince
    void textBox1_EnterPressed();   // textBox1: Enter'a basılınca
    void checkbox1_Checked();   // checkbox1: İşaret değişince
    void radioButton1_Click();   // radioButton1: Seçilince
    void sliderFloat1_ValueChanged();   // sliderFloat1: Değer kayarken
    void sliderFloat1_Deactivated();   // sliderFloat1: Kaydırma bitince
    void combo1_SelectionChanged();   // combo1: Seçim değişince
    void listBox1_SelectionChanged();   // listBox1: Seçim değişince
    void progressBar1_Hovered();   // progressBar1: Fare üstüne gelince
    void tabBar1_TabChanged();   // tabBar1: Aktif sekme değişince
    void button2_Click();   // button2: Tıklandığında
    void button2_Hovered();   // button2: Fare üstüne gelince
    void button2_Held();   // button2: Basılı tutulunca
    void textBox2_TextChanged();   // textBox2: Yazı değişince
    void textBox2_EnterPressed();   // textBox2: Enter'a basılınca
    void OnLoad() override;
    Form1();
    ~Form1() override;   // vtable bu TU'da bağlanır
    void Render() override;
};
