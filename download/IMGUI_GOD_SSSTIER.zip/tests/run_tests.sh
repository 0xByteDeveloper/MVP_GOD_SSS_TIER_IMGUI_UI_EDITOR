#!/bin/bash
# run_tests.sh — IMGUI GOD SSS TIER editör test paketi (Wine + Xvfb altında)
# Kullanım: ./run_tests.sh
# Çıktı: her test için PASS/FAIL + özet
set -u
cd "$(dirname "$0")/.."
export WINEPREFIX=/home/z/my-project/work/.wine64
export DISPLAY=:97
WINE=/home/z/my-project/tools/bin/wine64
EXE=Bin/imgod_editor_x64.exe
PASS=0; FAIL=0; FAILED=()

pkill -f "Xvfb :97" 2>/dev/null; sleep 0.5
Xvfb :97 -screen 0 1680x960x24 > /tmp/xvfb_test.log 2>&1 &
XPID=$!
trap 'kill $XPID 2>/dev/null' EXIT
sleep 1.5

run_editor() {   # <selftest> <saniye>
    (cd Bin && rm -f state_*.imgod && "$WINE" ./imgod_editor_x64.exe --selftest "$1" > /tmp/wine_test.log 2>&1) &
    local pid=$!
    sleep "$2"
    kill $pid 2>/dev/null; sleep 0.7
    "$WINE" -k 2>/dev/null; /home/z/my-project/tools/bin/wineserver64 -k 2>/dev/null
    sleep 0.5
}

check() {  # <ad> <koşul-komutu>
    if eval "$2" >/dev/null 2>&1; then
        echo "  [PASS] $1"; PASS=$((PASS+1))
    else
        echo "  [FAIL] $1"; FAIL=$((FAIL+1)); FAILED+=("$1")
    fi
}

echo "=== TEST 1: temel (ekleme/özellik/kayıt) ==="
run_editor ../tests/test_basic.txt 12
check "kayıt oluştu" '[ -s Bin/state_basic.imgod ]'
check "3 nesne" 'python3 -c "import json;d=json.load(open(\"Bin/state_basic.imgod\"));exit(0 if len(d[\"Forms\"][0][\"Ctrls\"])==3 else 1)"'
check "renk özelliği korundu" 'grep -q "D25410" Bin/state_basic.imgod'
check "Türkçe metin korundu" 'grep -q "Merhaba Dünya" Bin/state_basic.imgod'

echo "=== TEST 2: etkileşim (arm/yerleştir/rubber band/pano) ==="
run_editor ../tests/test_interact.txt 20
check "kayıt oluştu" '[ -s Bin/state_interact.imgod ]'
check "yerleştirme: 8 nesne (3+1 yerleşik+4 yapıştırılan)" 'python3 -c "import json;d=json.load(open(\"Bin/state_interact.imgod\"));exit(0 if len(d[\"Forms\"][0][\"Ctrls\"])==8 else 1)"'
check "yerleştirilen button2 var" 'grep -q "\"button2\"" Bin/state_interact.imgod'
check "yapıştırılan button3 var (tip sayacı)" 'grep -q "\"button3\"" Bin/state_interact.imgod'

echo "=== TEST 3: pano yeniden adlandırma (denemebutton → button2 tarzı) ==="
run_editor ../tests/test_clipboard.txt 14
check "kayıt oluştu" '[ -s Bin/state_clip.imgod ]'
check "yapıştırılanlar tip adıyla: 4 nesne" 'python3 -c "import json;d=json.load(open(\"Bin/state_clip.imgod\"));exit(0 if len(d[\"Forms\"][0][\"Ctrls\"])==4 else 1)"'
check "button2 (sayaç) oluştu" 'grep -q "\"button2\"" Bin/state_clip.imgod'
check "combo2 (sayaç) oluştu" 'grep -q "\"combo2\"" Bin/state_clip.imgod'

echo "=== TEST 4: çok formlu park/unpark ==="
run_editor ../tests/test_forms.txt 12
check "kayıt oluştu" '[ -s Bin/state_forms.imgod ]'
check "2 form" 'python3 -c "import json;d=json.load(open(\"Bin/state_forms.imgod\"));exit(0 if d.get(\"FormCount\")==2 else 1)"'
check "Form1 button1 park edildi" 'python3 -c "
import json;d=json.load(open(\"Bin/state_forms.imgod\"))
names=[f[\"FormName\"] for f in d[\"Forms\"]];exit(0 if \"button1\" in json.dumps(d) else 1)"'

echo ""
echo "=========================================="
echo "SONUÇ: $PASS PASS / $FAIL FAIL"
if [ $FAIL -gt 0 ]; then
    printf 'BAŞARISIZ: %s\n' "${FAILED[*]}"
    exit 1
fi
echo "TÜM TESTLER GEÇTİ ✓"
